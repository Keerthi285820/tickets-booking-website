"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, CheckCircle2 } from "lucide-react"

export default function BookingForm() {
  const [ticketType, setTicketType] = useState("normal")
  const [quantity, setQuantity] = useState("1")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const ticketPrices = {
    premium: 12000,
    deluxe: 8000,
    normal: 3500,
  }

  const calculateTotal = () => {
    return ticketPrices[ticketType as keyof typeof ticketPrices] * Number.parseInt(quantity)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSuccess(true)
    }, 1500)
  }

  if (isSuccess) {
    return (
      <Card className="w-full">
        <CardHeader className="bg-green-50 border-b">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-8 w-8 text-green-500" />
            <div>
              <CardTitle>Booking Successful!</CardTitle>
              <CardDescription>Your tickets have been booked successfully.</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-500">Ticket Type</h4>
              <p className="text-lg capitalize">{ticketType} Ticket</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-500">Quantity</h4>
              <p className="text-lg">{quantity}</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-500">Total Amount</h4>
              <p className="text-lg font-bold">₹{calculateTotal().toLocaleString()}</p>
            </div>
            <div className="pt-4">
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200 flex gap-3">
                <AlertCircle className="h-5 w-5 text-yellow-500 shrink-0 mt-0.5" />
                <p className="text-sm text-yellow-700">
                  A confirmation email has been sent to your email address with the ticket details and QR code.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row gap-3">
          <Button className="w-full sm:w-auto" onClick={() => setIsSuccess(false)}>
            Book More Tickets
          </Button>
          <Button variant="outline" className="w-full sm:w-auto">
            Download E-Ticket
          </Button>
        </CardFooter>
      </Card>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Ticket Booking</CardTitle>
        <CardDescription>Fill in the details to book your tickets for the match.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input id="name" placeholder="Enter your full name" required />
            </div>

            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input id="email" type="email" placeholder="Enter your email address" required />
            </div>

            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" placeholder="Enter your phone number" required />
            </div>

            <div>
              <Label>Ticket Type</Label>
              <RadioGroup
                defaultValue="normal"
                className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2"
                onValueChange={setTicketType}
              >
                <div className="flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                  <RadioGroupItem value="premium" id="premium" />
                  <Label htmlFor="premium" className="cursor-pointer">
                    Premium (₹12,000)
                  </Label>
                </div>
                <div className="flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                  <RadioGroupItem value="deluxe" id="deluxe" />
                  <Label htmlFor="deluxe" className="cursor-pointer">
                    Deluxe (₹8,000)
                  </Label>
                </div>
                <div className="flex items-center space-x-2 border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                  <RadioGroupItem value="normal" id="normal" />
                  <Label htmlFor="normal" className="cursor-pointer">
                    Normal (₹3,500)
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label htmlFor="quantity">Number of Tickets</Label>
              <Select defaultValue="1" onValueChange={setQuantity}>
                <SelectTrigger>
                  <SelectValue placeholder="Select quantity" />
                </SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 4, 5, 6].map((num) => (
                    <SelectItem key={num} value={num.toString()}>
                      {num}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="pt-4 border-t">
            <div className="flex justify-between mb-2">
              <span>Ticket Price:</span>
              <span>₹{ticketPrices[ticketType as keyof typeof ticketPrices].toLocaleString()}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span>Quantity:</span>
              <span>{quantity}</span>
            </div>
            <div className="flex justify-between font-bold text-lg">
              <span>Total Amount:</span>
              <span>₹{calculateTotal().toLocaleString()}</span>
            </div>
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
            {isSubmitting ? "Processing..." : "Confirm Booking"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
