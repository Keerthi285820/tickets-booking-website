import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import { cn } from "@/lib/utils"

interface TicketCardProps {
  title: string
  price: number
  image: string
  features: string[]
  color: string
}

export default function TicketCard({ title, price, image, features, color }: TicketCardProps) {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg transition-transform hover:scale-105 hover:shadow-xl">
      <div className="relative h-48">
        <Image src={image || "/placeholder.svg"} alt={title} fill className="object-cover" />
        <div className={cn("absolute inset-0 opacity-80", color)}></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <h3 className="text-2xl font-bold text-white">{title}</h3>
        </div>
      </div>

      <div className="p-6">
        <div className="mb-6 text-center">
          <span className="text-3xl font-bold">₹{price.toLocaleString()}</span>
          <span className="text-gray-600"> / ticket</span>
        </div>

        <ul className="space-y-3 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>

        <Button className="w-full" size="lg" href="#book-tickets">
          Book Now
        </Button>
      </div>
    </div>
  )
}
